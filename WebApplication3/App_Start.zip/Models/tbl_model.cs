﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Models
{
    public class tbl_model
    {
        public string name { get; set; }
        public string cnt { get; set; }
        public string qualification { get; set; }
        public string email { get; set; }
    }
}