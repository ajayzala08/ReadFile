﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.Models
{
    public class tble_model
    {
        public string name { get; set; }
        public string cnt { get; set; }
        public string qualification { get; set; }
        public string email { get; set; }
        public string company { get; set; }
        public string designation { get; set; }
        public string location { get; set; }

    }
}